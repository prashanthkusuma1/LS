const create = (data, covCd) => {
  if (covCd != undefined) {
    data.coverageParts.forEach((element) => {
      element.coverages.forEach((cov) => {
        if (cov.coverageCd === covCd) return (data.text = "working");
      });
    });
  }
  return null;
};
